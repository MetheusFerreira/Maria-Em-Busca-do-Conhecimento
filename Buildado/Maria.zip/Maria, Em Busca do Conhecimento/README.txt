		Instalar o Jogo

1 - Descompacte o arquivo "Maria.zip";
2 - Abra a pasta "Maria, Em Busca do Conhecimento";
3 - Clique duas vezes no arquivo "Maria, provavelmente.exe";
4 - Divirta-se.

		Controles

Pular: 		Barra de Espaço

	Pule os cactos e colete os fonemas para poder ganhar o jogo.